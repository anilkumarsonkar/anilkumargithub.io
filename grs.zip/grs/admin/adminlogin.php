<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"
        type="text/css" />
        <script src="..js/bootstrap.bundle.js"></script>
        <link href="../css/admin.css" rel="stylesheet" type="text/css"/>
        <style>
            body{
                background-image:url('../images/admin.jpg');
        background-size:cover;
            }

.c2 {
/* fallback for old browsers */
background: #fccb90;


 background-image:url('../images/r4.jpeg'); */
        background-size:cover; 
        background-size:100% 100%;
        border-radius:10px;
}
.footer{
        height:50px;
        width:100%;
        box-shadow:5px 5px 15px black;
        background-color: hwb(180 80% 5%);
        color:black;
        margin-top:15px;
    }
    
    .c{
        padding: auto;
    }
    form{
     width:700px;
     border-radius:10px;
     box-shadow:2px 2px 10px grey;
     
    }
    input{
      width:400px;
    }

            </style>
</head>
<body>
<nav class="navbar navbar-expand-lg  header bg-info" style="height:50px;">
  <div class="container-fluid mb-2">
    <a class="navbar-brand" href="#"><i class="fa-brands fa-facebook-f"></i> </a>
    <a class="navbar-brand" href="#">
    <i class="fa-brands fa-x-twitter"></i> </a>

<a class="navbar-brand" href="#">
<i class="fa-brands fa-linkedin-in"></i> 
<a class="navbar-brand" href="#">
<i class="fa-brands fa-instagram"></i></a>
<a class="navbar-brand" href="#">
<i class="fa-brands fa-google-plus-g"></i></a>

<a class="navbar-brand" href="#" >
<i class="fa-solid fa-phone-volume" style="margin-left:845px;"></i>+917233819626</a>
<a class="navbar-brand" href="#">
  <i class="fa-regular fa-envelope"></i> Sonkar7233@gmail.com</a>
  <a class="navbar-brand" href="index.php">
<i class="fa-solid fa-right-from-bracket"></i> Back</a>

   
   
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      
    </div>
  </div>
</nav>
<section>
<h1 align="center"><img src="../images/mithla.jpg" style=" width:130px; border-radius:50%"/></h1>
            <h2 align="center" style="text-shadow:1px 1px 2px red; color:white"><b>Lalit Narayan Mithila University, Darbhanga</i></b></h2>
           
            <h3 align="center" style="text-shadow:1px 1px 2px red; color:white">
                    <b> Grienvance Redressal Portal</b>
            </h3>
 
          <div class="row m-0 p-0">
            <div class="col-sm-6">
              <div class="card-body">
                <div class="text-center"> 
                  
                </div>

                <form action="alogcode.php" method="post">
                  <center>
                  <img src="../images/admn.png" style="border-radius:50%; height:60px;width:60px; margin-top:10px;"/>
                 
                  <h3 style="text-shadow:1px 1px 2px red;"></b>ADMIN LOGIN</b></h3>

                  <div class="form-outline mb-2">
                    <input type="email" class="form-control"
                      placeholder="Email address" name="em" style=" width:400px; margin-left:50px;" />
                    <label class="form-label" for="form2Example11">AdminEmail</label>
                  </div>

                  <div class="form-outline mb-4">
                    <input type="password" placeholder="Password" class="form-control" name="pa" style=" width:400px; margin-left:50px;" />
                    <label class="form-label" for="form2Example22">Password</label>
                  </div>

                  <div class="text-center pt-1 mb-5 pb-1">
                    <button class="btn btn-primary  fa-lg" type="submit" style="height:40px; width:300px; margin-right:200px;  margin-left:200px;">Login
                     </button>
                    
                  </div>
                  <a class="text-muted" href="#!">Forgot password?</a>

                 
</center>
                </form>

              </div>
            </div>
            <div class="col-sm-6 d-flex align-items-center justify-content-center gradient-custom-2 c2">
              <div class="text-black">
              
                 
              </div>
             
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row m-0 p-0">
    <div class="col-sm-12 footer">
<p align="center" style=" margin-top:15px;">&copy;CopyRights Disigned and develop by <b></i>Anil kumar sonkar</i></b></p>
    </div>
</div>
</section>

</body>
</html>