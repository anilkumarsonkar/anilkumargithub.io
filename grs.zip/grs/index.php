<html>
    <head>
<link href="./css/bootstrap.css" rel="stylesheet" type="text/css"/>
<script src="./js/bootstrap.bundle.js"></script>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    .log-card{
        height:150px;
        width:100%;
        box-shadow:0px 0px 5px gray inset;
        border-radius:10px;
         background-color: #eef5f5; 
        
    }
   
    .footer{
        height:60px;
        width:100%;
        box-shadow:5px 5px 15px black;
        margin-top:98px;
        background-color: hsl(180, 30%, 72%);
        color:black;
        
    }
    .header{
      background-color: hsl(180, 30%, 72%);
    }
    .a{
        font-size:50px;
        margin-left:50px;
        margin-top:40px;

    }
    a{
        text-decoration:none;
        color:black;
    }
    .u{
        font-size:30px;
        color:black;
        text-align:center;
        margin-left:30px;
    }
    .log-card:hover{
        
      background-color: hwb(180 74% 6%);
        box-shadow:5px 5px 15px skyblue inset;
        transform:scale(1.2);
        

    }
    body{
        background-image:url('./images/bg.avif');
        background-size:cover;
        
    }
    nav{
      color:white;
    }
    
    </style>
    </head>
    <body>
        <div id="outer" class="container-fluid">
            <div class="row">
            <nav class="navbar navbar-expand-lg  header">
  <div class="container-fluid h">
    <a class="navbar-brand" href="#"><i class="fa-brands fa-facebook-f"></i> </a>
    <a class="navbar-brand" href="#">
    <i class="fa-brands fa-x-twitter"></i> </a>

<a class="navbar-brand" href="#">
<i class="fa-brands fa-linkedin-in"></i> 
<a class="navbar-brand" href="#">
<i class="fa-brands fa-instagram"></i></a>
<a class="navbar-brand" href="#">
<i class="fa-brands fa-google-plus-g"></i></a>
<a class="navbar-brand" href="#" style="margin-left:920px;">
<i class="fa-solid fa-phone-volume"></i> +917233819626</a>
<a class="navbar-brand" href="#">
  <i class="fa-regular fa-envelope"></i> Sonkar7233@gmail.com</a>

   
   
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      
    </div>
  </div>
</nav>
            </div>
            <h1 align="center"><img src="./images/mithla.jpg" style="width:170px; border-radius:50%; margin-top:20px;"/></h1>
            <h2 align="center"  style="color:;">Lalit Narayan Mithila University, Darbhanga</h2>
           
            <h3 align="center" style=" color:black;">
                     Grienvance Redressal Portal
            </h3>
            <div class="row tr">
                <div class="col-sm-4 p-5">
                    <div class="log-card">
                    <a href="admin/adminlogin.php"> <i class="fa-regular fa-user a" ></i>
                    <span class="u">Admin Login</span></a>
                    </div>
                </div>
                <div class="col-sm-4 p-5">
                <div class="log-card">
                <a href="registraion.php"> <i class="fa-solid fa-users a"></i>
                <span class="u">User Registration</span></a>
               
                </div>
                </div>
                <div class="col-sm-4 p-5">
                <div class="log-card">

                    <a href="login.php"><i class="fa-solid fa-graduation-cap a"></i>
                    <span class="u">Student Login</span></a>
                </div>
                </div>
</div>
</div>
<div class="row m-0 p-0">
    <div class="col-sm-12 footer">
<p align="center" style="margin-top:15px;">&copy;CopyRights Disigned and develop by <b><i>Anil kumar sonkar</i></b></p>
    </div>
</div>
    </body>
</html>